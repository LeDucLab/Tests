# Belehrungen · Testversion ohne Login

Diese Version öffnet ohne Anmeldung, Entra-Einrichtung oder Secrets. Alle Besucher können in der Seitenleiste zwischen Mitarbeiter und Verwaltung wechseln und jeden Mitarbeiter auswählen. Die Ansichten sind keine Zugriffskontrolle. Auch Downloads, Import und Prüfentscheidungen sind für alle zugänglich. Nur mit fiktiven Daten testen. Die ursprünglich gewünschte vertrauliche Gesamtübersicht ist ohne zusätzliche Zugriffskontrolle nicht gewährleistet.

## Streamlit Community Cloud

1. Den Inhalt dieses Ordners (app.py, core.py, requirements.txt und .streamlit/config.toml) in das Stammverzeichnis eines GitHub-Repositories hochladen. Keine Datenbank oder echten Nachweise hochladen.
2. Auf https://share.streamlit.io eine App erstellen und Repository, Branch und app.py auswählen. Python 3.12 verwenden.
3. Deploy klicken. Keine Secrets nötig. Falls die vorherige Version bereits läuft, Dateien ersetzen und nicht mehr benötigte Auth-Secrets entfernen.
4. Die App startet mit zwei fiktiven Mitarbeitern und allen sechs Belehrungen für das aktuelle Jahr. Unter Verwaltung lassen sich die Jahreskonfiguration und Mitarbeiterimporte testen.

## Lokal starten

Python 3.11 oder neuer verwenden:

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Testablauf

In der Mitarbeiteransicht Erika Mustermann auswählen. Eine Test-PDF z. B. Datenschutz_Mustermann_Erika_2026.pdf hochladen; das Dateijahr muss zum gewählten Jahr passen. Unter Verwaltung → Gesamtübersicht die Datei herunterladen und den Status bestätigen. Danach die Mitarbeiterübersicht prüfen.

Uploads werden anhand von Belehrungsart, Name und Jahr im Dateinamen zugeordnet. Format: Datenschutz_Nachname_Vorname_Jahr.pdf. Keine OCR oder inhaltliche Echtheitsprüfung. PDF-Kennung und Größe (maximal 10 MB) werden geprüft. Pro Person, Art und Jahr ist ein Nachweis möglich; Dubletten überschreiben nichts. Austausch, Löschen, Kommentare und individuelle Pflichtausnahmen sind nicht enthalten. Namen dürfen Leerzeichen und Bindestriche enthalten, aber keine Unterstriche.

Pflichtbelehrungen: Datenschutz, Compliance, Händehygiene, Brandschutz, Arbeitsschutz, Energiemanagement. Die Verwaltung legt sie jährlich für beide Bereiche fest. Status: Offen, Eingereicht, Bestätigt, Rückfrage. Hochladen bedeutet zunächst nur Eingereicht.

## Mitarbeiterimport

CSV mit Semikolon und Spalten subject;nachname;vorname;bereich. subject ist jetzt eine selbst vergebene stabile Mitarbeiter-ID, kein Login-Konto. Bereich muss CMTD oder GYN sein. Vorlage mit fiktiven Beispielen liegt bei. Bestehende IDs werden aktualisiert; fehlende Personen nicht gelöscht. Die Startbeispiele haben die IDs test-cmtd und test-gyn und bleiben beim Import erhalten. Neue IDs aus der Vorlage erzeugen zusätzliche Personen.

## Speicherung und Grenzen

SQLite-Datei: data/belehrungen_ohne_login.db. Alternativ BELEHRUNGEN_DB setzen. Testbeispiele werden nur bei der ersten Initialisierung erzeugt. Auf Community Cloud ist diese lokale Ablage nicht als dauerhafte Speicherung zu behandeln; Testdaten können bei Neustart oder Neuaufbau verloren gehen. Externe persistente Speicherung ist nicht eingerichtet.

Das Protokoll dokumentiert die gewählte Mitarbeiter-ID bzw. verwaltung-ohne-login, keine nachgewiesene Identität. Keine geschützten Rollen. Keine Anmeldung und kein Passwort erforderlich.

## Prüfungen

```bash
python -m unittest -v
```
