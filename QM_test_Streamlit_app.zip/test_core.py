import tempfile
import unittest
from pathlib import Path
from core import connect, import_staff, recognize, submit

class WorkflowTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = connect(Path(self.tmp.name) / 'test.db')
        import_staff(self.db, b'subject;nachname;vorname;bereich\na;Mueller;Erika;CMTD\nb;Schmidt;Eva;GYN\n', 'admin')
    def tearDown(self):
        self.db.close()
        self.tmp.cleanup()
    def test_upload_and_duplicate(self):
        submit(self.db, 'a', 'Datenschutz_Mueller_Erika_2026.pdf', b'%PDF-1.4 test', 2026, ['Datenschutz'])
        self.assertEqual(self.db.execute('SELECT status FROM evidence').fetchone()[0], 'Eingereicht')
        with self.assertRaises(ValueError):
            submit(self.db, 'a', 'Datenschutz_Mueller_Erika_2026.pdf', b'%PDF-test', 2026, ['Datenschutz'])
        self.assertEqual(self.db.execute('SELECT count(*) FROM evidence WHERE subject=?', ('b',)).fetchone()[0], 0)
    def test_foreign_name_year_and_format(self):
        for name, data in [('Datenschutz_Schmidt_Eva_2026.pdf', b'%PDF-test'), ('Datenschutz_Mueller_Erika_2025.pdf', b'%PDF-test'), ('Datenschutz_Mueller_Erika_2026.pdf', b'fake')]:
            with self.assertRaises(ValueError):
                submit(self.db, 'a', name, data, 2026, ['Datenschutz'])
        self.assertEqual(self.db.execute('SELECT count(*) FROM evidence').fetchone()[0], 0)
    def test_import_atomic(self):
        with self.assertRaises(ValueError):
            import_staff(self.db, b'subject;nachname;vorname;bereich\nc;Test;Anna;GYN\nd;Test;Ben;OTHER', 'admin')
        self.assertEqual(self.db.execute('SELECT count(*) FROM employees').fetchone()[0], 2)
    def test_umlaut(self):
        self.assertEqual(recognize('Haendehygiene_Müller_Erika_2026.pdf', {'nachname':'Mueller', 'vorname':'Erika'}), ('Händehygiene', 2026))

if __name__ == '__main__':
    unittest.main()
